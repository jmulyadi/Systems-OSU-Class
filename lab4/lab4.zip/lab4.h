/* Josh Mulyadi */

bool init(int argc);
int main(int argc, char *argv[]);
void print_end(double start, int rval);
void teardown();
