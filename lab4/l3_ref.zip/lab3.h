/* Neil Kirby */

bool init();
int main();
void teardown();
