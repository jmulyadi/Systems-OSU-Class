/* Neil Kirby */

bool good_input(struct Sim *world);
bool valid_input(unsigned short code);
