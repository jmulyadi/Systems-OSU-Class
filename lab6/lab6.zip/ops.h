/* Neil Kirby */

int divide(int a, int b);
int left_shift(int a, int b);
int plus(int a, int b);
int times(int a, int b);
