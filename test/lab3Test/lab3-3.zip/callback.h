/* Josh Mulyadi */

bool all(void *data, void *helper);
void all_done(void *data);
bool all_left_of_flag(void *data, void *helper);
bool coinInsert(void *data1, void *data2);
bool mascotInsert(void *data1, void *data2);
void move(void *data);
bool my_coin(void *data, void *helper);
void print_coins(void *data);
void print_mascots(void *data);
bool sort_mascots_y(void *data1, void *data2);
bool sort_points(void *data1, void *data2);
void sweep_coins(void *data);
