/* Josh Mulyadi */

void collect_coins(struct Sim *world);
void free_all(struct Sim *world);
bool game_on(struct Sim *world);
void run_sim(struct Sim *world);
