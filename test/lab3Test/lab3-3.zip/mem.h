/* Josh Mulyadi */

void *allocate(bool wantMascot);
void freeMem(void *data);
int main();
void *makeWorld();
