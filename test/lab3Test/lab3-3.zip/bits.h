/* Josh Mulyadi */

unsigned int get_VX(unsigned short code);
unsigned int get_coin_x(unsigned short code);
unsigned int get_coin_y(unsigned short code);
unsigned int get_color(unsigned short code);
unsigned int get_jump_V(unsigned short code);
bool isCoin(unsigned short code);
bool isMascot(unsigned short code);
bool valid_brutus(unsigned short code);
bool validateCoin(unsigned short code);
