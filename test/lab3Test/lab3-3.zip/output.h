/* Josh Mulyadi */

void ceiling_message(struct Buckeye *brutus);
void clear_coins(struct Sim *world);
void clear_mascots(struct Sim *world);
void final_output(struct Sim *world);
void flag_message(struct Buckeye *brutus);
void floor_message(struct Buckeye *brutus);
void jump_message(struct Buckeye *brutus);
void loot_message(struct Buckeye *brutus);
void master_output(struct Sim *world);
void output_bad_bits(unsigned short code);
void output_scanf(int tokens);
