/* Josh Mulyadi */

unsigned int get_coin_x(unsigned short code);
unsigned int get_coin_y(unsigned short code);
unsigned int get_color(unsigned short code);
bool isCoin(unsigned short code);
bool isMascot(unsigned short code);
int main();
bool validateCoin(unsigned short code);
