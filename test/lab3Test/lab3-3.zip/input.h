/* Josh Mulyadi */

void deal_with_coin(unsigned short code, struct Sim *world);
void deal_with_input(unsigned short code, struct Sim *world);
void deal_with_mascot(unsigned short code,struct Sim *world);
bool good_input(struct Sim *world);
