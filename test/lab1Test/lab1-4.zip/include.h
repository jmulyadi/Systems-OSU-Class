/*Josh Mulyadi*/
#define INIT 1
