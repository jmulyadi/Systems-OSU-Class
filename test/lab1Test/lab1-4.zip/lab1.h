/* Josh Mulyadi */

int doubleIt(int x);
int foo(int x);
int main();
