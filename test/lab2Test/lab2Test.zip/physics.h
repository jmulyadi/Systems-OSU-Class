/* Josh Mulyadi */

void X_shift(double brutus[], double *time, int color);
void Y_shift(double brutus[]);
void both_shift(double brutus[], double *time, int color);
void move_brutus(double brutus[]);
