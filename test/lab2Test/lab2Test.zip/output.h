/* Josh Mulyadi */

void brutusCeilingText(double brutus[], double temp_Y_POS);
void brutusJumpText(double *time, double brutus[], int color);
void endText(double brutus[], double time, int color);
void flag_graphics(double brutus[], int color, double time);
int good_input_run();
int init();
double master_graphics(double brutus[], int color);
double master_output(double brutus[], int color);
void master_text(double brutus[], int color);
void printHitFloorCeiling(double brutus[], double original_Y_VEL);
void teardown();
void time_adjust(double *time);
void writeGraphics(double brutus[], int color);
