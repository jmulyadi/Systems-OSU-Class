/* Josh Mulyadi */

int main() {;
int readInput(double brutus[]);
