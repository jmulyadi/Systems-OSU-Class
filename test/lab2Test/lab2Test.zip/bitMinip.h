/* Josh Mulyadi */

int checkBit(unsigned short hexNum);
int checkColor(unsigned short hexNum);
int checkJumpVel(unsigned short hexNum);
int checkX_VEL(unsigned short hexNum);
int main();
int validateInput(unsigned short hexNum);
