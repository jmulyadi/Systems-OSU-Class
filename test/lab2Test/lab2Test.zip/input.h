/* Josh Mulyadi */

int isInputGood(unsigned short hexNum, double brutus[], int color);
int readInput();
