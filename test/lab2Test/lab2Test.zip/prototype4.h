/* Josh Mulyadi */

int main();
void master_text(double brutus[], int color);
