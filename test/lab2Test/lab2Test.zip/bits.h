/* Josh Mulyadi */

int checkColor(unsigned short hexNum);
double checkJumpVel(unsigned short hexNum);
double check_X_VEL(unsigned short hexNum);
int decodeBits(unsigned short hexNum, double brutus[]);
int validateInput(unsigned short hexNum, double brutus[], int color);
