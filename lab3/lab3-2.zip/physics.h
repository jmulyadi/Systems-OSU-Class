/* Josh Mulyadi */

bool close_enough(struct Coin *c, struct Buckeye *b);
bool is_left_of_flag(struct Buckeye *brutus);
void move_brutus(struct Buckeye *brutus);
