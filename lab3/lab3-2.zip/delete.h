/* Josh Mulyadi */

bool deleteAll(void *data, void *helper);
bool deleteUpperCase(void *data, void *helper);
void disposal(void *data);
bool first_letter(void *data1, void *data2);
int main();
void print(void *data);
