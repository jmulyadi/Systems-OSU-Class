/* Josh Mulyadi */

int get_score(struct Buckeye *brutus);
bool init();
int main();
void teardown();
