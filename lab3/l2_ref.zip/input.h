/* Neil Kirby */

bool good_input_run();
