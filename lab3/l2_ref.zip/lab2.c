// COpyright 2024 Neil Kirby
// Not for distribution without permission

// list < > style headers first
#include <stdio.h>
#include <stdlib.h>

// includ3 constants and structs next
#include "subscripts.h"
#include "constants.h"
#include "debug.h"

// library headers that don't have bugs
#include "btp.h"

// include function declarations after that
#include "n2.h"

#include "bits.h"
#include "input.h"
#include "output.h"
#include "physics.h"

// include our own file last
#include "lab2.h"

int get_score(double brutus[])
{
	if(is_left_of_flag(brutus))
	{
	    return (int) brutus[X_POSITION];
	}
	else
	{
	    return (int)  (brutus[X_POSITION] + brutus[Y_POSITION]);
	}
}

void sim_loop(int color, double brutus[])
{
	double elapsed = 0.0;

	while(is_left_of_flag(brutus))
	{
	    master_output(elapsed,  get_score(brutus), color, brutus);

	    elapsed += DELTA_TIME;
	    move_brutus(brutus);

	}
	final_output(elapsed, get_score(brutus), color, brutus);

}

void load_and_go(unsigned short code)
{
	// the 0.5 values are the start position
	// the 6.0 are safety values better than zero
    
	double brutus[5] = { 0.5, 0.5, 6.0, 0.0, 6.0};

	brutus[X_VELOCITY] = get_VX(code);
	brutus[JUMP_VELOCITY] = get_jump_V(code);

	sim_loop(get_color(code), brutus);
}



#define RVAL_BAD_INIT (1)
#define RVAL_BAD_INPUT (2)


/* I own all inits.  In future labs, I might morph to master init and call
 * my init minions to do the various subtasks.  For now, I'm simple enough
 * to do it all easily myself.  I shield main for all details about
 * initializations */
bool init()
{
	/* we might take manual control over what we feed btp_init
	 * SO that we turn it off but still debug our code. */
	return(TEXT || ( GRAPHICS && btp_initialize(false)));

}

/* Put all of the toys away.  In future labs I will own more stuff and
 * call my minions to do those things. */
void teardown()
{
	if(GRAPHICS)btp_teardown();
}


/* Avoid details and call upon my minions to make it everything happen.  I own
 * those highest level things that I must own: performance timing and the
 * value we return to linux */
int main()
{
	int rval = EXIT_SUCCESS;
	double start, runtime;

	start = now();	// this is the very first executable statement

	if( init())
	{
	    if( !good_input_run()) rval = RVAL_BAD_INPUT;
	    teardown();
	}
	else
	{
	    rval = RVAL_BAD_INIT;	// non zero, indicates an error
	}
	
	/* at this point we are done, graphics has been torn down*/
	printf("Returning %d\n", rval);
	runtime = now() - start;
	/* after graphics has been torn down, we can freely print */
	printf("Total runtime is %.9lf seconds\n", runtime);

	return rval;
}

