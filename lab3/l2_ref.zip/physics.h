/* Neil Kirby */

bool is_left_of_flag(double brutus[]);
void move_brutus(double brutus[]);
