/* Neil Kirby */

int get_score(double brutus[]);
bool init();
void load_and_go(unsigned short code);
int main();
void sim_loop(int color, double brutus[]);
void teardown();
