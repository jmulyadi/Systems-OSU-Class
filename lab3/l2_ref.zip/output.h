/* Neil Kirby */

void ceiling_message(double brutus[]);
void final_output( double elapsed, int score, int color, double brutus[]);
void floor_message(double brutus[]);
void jump_message(double brutus[]);
void master_output( double elapsed, int score, int color, double brutus[]);
void output_bad_bits(unsigned short code);
void output_scanf(int tokens);
