// Copyright 2024 Neil Kirby
// Not for distribution without permission

// Include < > style headers first:
#include <stdio.h>

// include debug, subscripts, etc before functions
#include "debug.h"
#include "btp.h"
#include "subscripts.h"
#include "constants.h"

// include any function headers now, other than our own.
#include "n2.h"

// include the header file for this file as the very last include
#include "output.h"



static void draw_brutus(int score, int color, double brutus[])
{
    btp_brutus( score, color, brutus[X_POSITION], brutus[Y_POSITION], true);
}

static void master_draw( double elapsed, int score, int color, double brutus[])
{


	btp_clear();
	btp_time( (int) (1000 * elapsed));

	// in future labs there are many plumbers at once
	draw_brutus(score, color, brutus);

	btp_refresh();
	microsleep( (unsigned int) (DELTA_TIME * 1000000));
}

static void print_brutus (int score, int color, double brutus[])
{
	printf("%3d    %d    (%8.5lf, %8.5lf)    (%9.5lf, %9.5lf)\n",
	    score, color, 
	    brutus[X_POSITION],
	    brutus[Y_POSITION],
	    brutus[X_VELOCITY],
	    brutus[Y_VELOCITY]);

}

static void master_print(double elapsed, int score, int color, double brutus[])
{
	// do the header, then brutus
	
printf(
    "\nPts    C    (__X_____, __Y_____)    (__VX_____, __VY_____) ET=%8.5lf\n",
    elapsed);
    	print_brutus(score, color, brutus);
}

static void final_draw ( double elapsed, int score, int color, double brutus[])
{
	double delay = 0.0;
	while (delay < 4.0)
	{
	    master_draw(elapsed, score, color, brutus);
	    delay += DELTA_TIME;
	}
}
	
void final_output( double elapsed, int score, int color, double brutus[])
{
	if(GRAPHICS)
	{
	    btp_status("Brutus makes it to the flag");
	    final_draw(elapsed, score, color, brutus);
	}
	if(TEXT)
	{
	    printf("\nBrutus makes it to the flag!\n");
	    master_print(elapsed, score, color, brutus);
	}
}

void master_output( double elapsed, int score, int color, double brutus[])
{
	if(GRAPHICS)master_draw(elapsed, score, color, brutus);
	if(TEXT)master_print(elapsed, score, color, brutus);
}

// messages
void ceiling_message(double brutus[])
{
	if(TEXT)printf("Brutus hits the ceiling at %8.5lf, %8.5lf\n",
		brutus[X_POSITION], brutus[Y_POSITION]);
	if(GRAPHICS)btp_status("Brutus hits the ceiling");

}

void floor_message(double brutus[])
{
	if(TEXT)printf("Brutus hits the floor at %8.5lf, %8.5lf\n",
		brutus[X_POSITION], brutus[Y_POSITION]);
	if(GRAPHICS)btp_status("Brutus hits the floor");

}

void jump_message(double brutus[])
{
	if(TEXT)printf("Brutus jumps at %8.5lf, %8.5lf\n",
		brutus[X_POSITION], brutus[Y_POSITION]);
	if(GRAPHICS)btp_status("Brutus jumps");

}


void output_bad_bits(unsigned short code)
{
	if(TEXT)printf("ERROR: invalid input: hex %X\n", code);
}

void output_scanf(int tokens)
{
	if(TEXT)printf("scanf returned %d\n", tokens);
}

/*
void final_output()
{
	if(TEXT)final_print();
	if(GRAPHICS)final_draw();
}
*/

