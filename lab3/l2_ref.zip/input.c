
/* Copyright 2023, Neil Kirby.  Not for disclosure without permission */

// put system shared libraries first - they are unlikely to have bugs.
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// put our own header files next.
// Start with one that are #define and structs

// includes for header files based on our own C code goes here.
// Always include the header for the file itself
// THis validates the header declarations against the defninitions.
// We are spoiled by our automatically generated headers, but we still
// validate them.  We put the include for this file dead last.
#include "output.h"
#include "bits.h"
#include "physics.h"
#include "lab2.h"

#include "input.h"

bool good_input_run()
{
	int tokens;
	unsigned short code;


	while( 1 ==(tokens = scanf("%hx", &code )))
	{
	    if(valid_brutus(code)) 
	    {
	    	load_and_go(code);
	    }
	    else
	    {
	    	output_bad_bits(code);
		return(false);
	    }

	}
	output_scanf(tokens);
	return( tokens == EOF);

}

/* the lab 4 bonus code will have more input routines. */

