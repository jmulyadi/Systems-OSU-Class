
// COpyright 2024 Neil Kirby
// Not for distribution without permission

// list < > style headers first
#include <stdio.h>

// includ3 constants and structs next
#include "subscripts.h"
#include "btp.h"

// defines 
#include "constants.h"

// include function declarations after that
#include "output.h"

// include our own file last
#include "physics.h"

// stuff only we should know about
#define FLAG_LIMIT (13.25)
#define G ( -10.0 )

bool is_left_of_flag(double brutus[])
{
	return( brutus[X_POSITION] < FLAG_LIMIT);

}

static void basic_motion(double brutus[])
{

	brutus[X_POSITION] += DELTA_TIME * brutus[X_VELOCITY];
	brutus[Y_POSITION] += brutus[Y_VELOCITY] * DELTA_TIME + 
		0.5* G * DELTA_TIME * DELTA_TIME;
	brutus[Y_VELOCITY] += G * DELTA_TIME;
}

static void make_adjustments(double brutus[])
{
	double XA = btp_X_adjustment(brutus[X_POSITION], brutus[Y_POSITION]);
	brutus[X_POSITION] += XA;

	double YA = btp_Y_adjustment(brutus[X_POSITION], brutus[Y_POSITION]);
	brutus[Y_POSITION] += YA;

	if(YA != 0.0) brutus[Y_VELOCITY] = 0.0;
}


void move_brutus(double brutus[])
{
	double oldX = brutus[X_POSITION], oldY = brutus[Y_POSITION];
	double oldVY = brutus[Y_VELOCITY];

	basic_motion(brutus);
	make_adjustments(brutus);

	if((oldVY != 0.0) && (brutus[Y_VELOCITY] == 0.0))
	{
		// if I was moving in Y and now I am not, I hit
		// the floor (or maybe a ceiling)
		if(oldVY < 0.0)floor_message(brutus);
		if(oldVY > 0.0)ceiling_message(brutus);
	}

	// I didn't move, I have to jump.
	if(oldX == brutus[X_POSITION] && oldY == brutus[Y_POSITION]) 
	{
	    brutus[Y_VELOCITY] = brutus[JUMP_VELOCITY];
	    jump_message(brutus);
	}
}
	

